import os
os.environ['SDL_IME_SHOW_UI'] = '0'
import pygame as pg,sys,random
pg.init()
pg.mixer.init()
pg.key.stop_text_input()
pg.display.set_caption("snack")
sc = pg.display.set_mode((900, 1000))
S,G,F=30,30,7.5
sn=[(10,10),(10,11),(10,12)]
dr=(0,-1)
fd=(5,5)
fnt = pg.font.Font(None, 40)
fnt_b = pg.font.Font(None, 80)
fnt_b.set_bold(True)
bg_img = pg.image.load("bb.jpg")
bg_img = pg.transform.scale(bg_img, (900, 1000))
start_bg = pg.image.load("start_bg.jpg")
start_bg = pg.transform.scale(start_bg, (900, 1000))
head_img = pg.image.load("head.png").convert_alpha()
head_img = pg.transform.scale(head_img, (S, S))
bomb_img = pg.image.load("bomb.png").convert_alpha()
bomb_img = pg.transform.scale(bomb_img, (S, S))
food_img = pg.image.load("food.png").convert_alpha()
food_img = pg.transform.scale(food_img, (S, S))
pg.mixer.music.load("bgm.ogg")
pg.mixer.music.set_volume(0.5)
st = 2
btn_rect = pg.Rect(300, 400, 300, 80)
score = 0
def reset():
    global sn, dr, fd, st, score,bombs,F
    sn = [(10, 10), (10, 11), (10, 12)]
    dr = (0, -1)
    fd = (5, 5)
    st = 1
    score = 0
    F=7.5
    bombs = []
    for _ in range(2):
        while True:
            b = (random.randint(0, G - 1), random.randint(0, G - 1))
            if b not in sn and b != fd and b not in bombs:
                bombs.append(b)
                break
def draw_grid():
    sc.blit(bg_img,(0,0))
    for i in range(G):
        for j in range(G):
            pg.draw.rect(sc,'black',(j*S,i*S,S,S),1)
def draw_snake_food():
    sc.blit(food_img, (fd[0] * S, fd[1] * S))
    for index, part in enumerate(sn):
        if index == 0:
            sc.blit(head_img, (part[0] * S, part[1] * S))
            if dr == (0, -1):
                angle = 0
            elif dr == (0, 1):
                angle = 180
            elif dr == (-1, 0):
                angle = 90
            elif dr == (1, 0):
                angle = -90
            rotated_head = pg.transform.rotate(head_img, angle)
            rect = rotated_head.get_rect(center=(part[0] * S + S // 2, part[1] * S + S // 2))
            sc.blit(rotated_head, rect)
        else:
            pg.draw.rect(sc, 'yellow', (part[0] * S, part[1] * S, S, S))
    for b in bombs:
        sc.blit(bomb_img, (b[0] * S, b[1] * S))
pg.mixer.music.play(-1)
clk=pg.time.Clock()
while True:
    for e in pg.event.get():
        if e.type == pg.QUIT:
            pg.quit()
            sys.exit()
    if e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
        if st == 2 and btn_rect.collidepoint(e.pos):
            reset()
    keys = pg.key.get_pressed()
    if st==1:
        if keys[pg.K_w] and dr != (0, 1):
            dr = (0, -1)
        elif keys[pg.K_s] and dr != (0, -1):
            dr = (0, 1)
        elif keys[pg.K_a] and dr != (1, 0):
            dr = (-1, 0)
        elif keys[pg.K_d] and dr != (-1, 0):
            dr = (1, 0)
    else:
        if keys[pg.K_SPACE]:
            reset()
    if st==1:
        new_head = (sn[0][0] + dr[0], sn[0][1] + dr[1])
        if new_head[0] < 0 or new_head[0] >= G or new_head[1] < 0 or new_head[1] >= G or new_head in sn or new_head in bombs:
            st=0
        else:
            sn.insert(0, new_head)
            if new_head == fd:
                score += 1
                if F < 15:
                    F += 0.5
                while True:
                        fd = (random.randint(0, G - 1), random.randint(0, G - 1))
                        if fd not in sn:
                            break
                bombs = []
                for _ in range(2):
                    while True:
                        b = (random.randint(0, G - 1), random.randint(0, G - 1))
                        if b not in sn and b != fd and b not in bombs:
                            bombs.append(b)
                            break
            else:
                sn.pop()
    draw_grid()
    if st == 1:
        draw_snake_food()
    score_text = fnt.render(f"Score: {score}", True, (0,0,0))
    sc.blit(score_text, (20, 920))
    if st == 0:
        overlay = pg.Surface((900, 900))
        overlay.set_alpha(180)
        overlay.fill((255, 255, 255))
        sc.blit(overlay, (0, 0))
        over_text = fnt_b.render("GAME OVER", True, (255, 0, 0))
        tip_text = fnt.render("Press SPACE to restart", True, (0, 0, 0))
        sc.blit(over_text, (450 - over_text.get_width() // 2, 350))
        sc.blit(tip_text, (450 - tip_text.get_width() // 2, 480))
    if st == 2:
        sc.blit(start_bg, (0, 0))
        pg.draw.rect(sc, 'green', btn_rect)
        btn_text = fnt.render("START", True, (255, 255, 255))
        sc.blit(btn_text, (btn_rect.centerx - btn_text.get_width() // 2,
                           btn_rect.centery - btn_text.get_height() // 2))
    pg.display.update()
    clk.tick(F)